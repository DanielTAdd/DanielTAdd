## Facies Classification
This [notebook] is a demonstration of using a machine learning algorithm (support vector machine) to assign facies to well log data.  Training data has been assembled based on expert core description combined with wireline data from nine wells.  This data is used to train a support vector machine to indentify facies based only on wireline data.  The data was derived from the University of Kansas dataset


