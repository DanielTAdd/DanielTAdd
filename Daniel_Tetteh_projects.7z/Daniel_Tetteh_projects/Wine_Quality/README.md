## Facies Classification
This code is for a project I worked on to compared different clustering algorithms and to predict the quality of wine based on
their chemical properties.The code was written in R and I employed the use of PCA,MDS,CFA and EFA to determine any underlying relationships 
amongst the variables

